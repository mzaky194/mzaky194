require("./server/handler.js")

// >~~~~~~ Setting Bot & Owner  ~~~~~~~< //
global.owner = "𝗭𝗔𝗡𝗡𝗦😈"
global.namabot = "𝗭𝗔𝗡𝗡𝗦 𝗕𝗢𝗧 𝗩𝟳🐉" 
global.namaowner = "𝗭𝗔𝗡𝗡𝗦 𝗖𝗥𝗔𝗦𝗛𝗘𝗥♕"
global.linkgc = 'https://chat.whatsapp.com/IGpNtawrmEpGvLbgIztNE2'
global.packname = "𝗭𝗔𝗡𝗡𝗦 𝗕𝗢𝗧 𝗩𝟳"
global.author = "𝗭𝗔𝗡𝗡𝗦 𝗕𝗢𝗧 𝗩𝟳"


// >~~~~~~~~ Setting Channel ~~~~~~~~~< //
global.idsaluran = "120363413886315879@newsletter"
global.namasaluran = "ALL TESTI+INFO STOK GEGE"
global.linksaluran = "https://whatsapp.com/channel/0029Vb4l3t1AojYsxslmTV1F"

// >~~~~ Setting Grup Reseller Panel ~~~~~< //
global.linkgrupresellerpanel = "https://chat.whatsapp.com/BCNCZftbswg6ebSx8Qlu0R"
global.apidigitalocean = "-"


// >~~~~~~~~ Setting Payment ~~~~~~~~~< //
global.dana = "088279009956"
global.ovo = "Belum Tersedia"
global.gopay = "Belum Tersedia"
global.qris = "https://img101.pixhost.to/images/447/553458742_zannsbotz.jpg"


// >~~~~~~~ Setting Orderkuota ~~~~~~~~< //

global.QrisOrderKuota = "00020101021126670016COM.NOBUBANK.WWW01189360050300000879140214516154930107400303UMI51440014ID.CO.QRIS.WWW0215ID20253689173290303UMI5204541153033605802ID5915ZANNS OK21717156005DUMAI61052881162070703A0163047EDC"
global.ApikeyOrderKuota = "775504017364302632171715OKCT070A67F74BA89089A25D81364440366C"
global.IdMerchant = "OK2171715"
global.pinH2H = "2011"
global.passwordH2H = "zanns22"

global.ApikeyRestApi = "new"


// >~~~~~~~~ Setting Api Panel ~~~~~~~~< //

global.egg = "15" // Isi id egg
global.nestid = "5" // Isi id nest
global.loc = "1" // Isi id location
global.domain = "https://-"
global.apikey = "-" // Isi api ptla
global.capikey = "-" // Isi api ptlc


// >~~~~~~ Setting Api Cloudflare ~~~~~~~< //

global.apitoken_cloudflare = "-"
global.accountid_cloudflare = "-"
global.email_cloudflare = "-@gmail.com"


// >~~~~~~~~ Setting Message ~~~~~~~~~< //

global.msg = {
wait: "𝗠𝗲𝗺𝗽𝗿𝗼𝘀𝗲𝘀. . . ❗", 
owner: "𝗙𝗶𝘁𝘂𝗿 𝗶𝗻𝗶 𝗸𝗵𝘂𝘀𝘂𝘀 𝘂𝗻𝘁𝘂𝗸 𝗼𝘄𝗻𝗲𝗿〽️", 
group: "𝗙𝗶𝘁𝘂𝗿 𝗶𝗻𝗶 𝗵𝗮𝗻𝘆𝗮 𝘂𝗻𝘁𝘂𝗸 𝗴𝗿𝘂𝗽☢️", 
private: "𝗙𝗶𝘁𝘂𝗿 𝗶𝗻𝗶 𝘂𝗻𝘁𝘂𝗸 𝗱𝗮𝗹𝗮𝗺 𝗽𝗿𝗶𝘃𝗮𝘁𝗲 𝗰𝗵𝗮𝘁💬", 
admin: "𝗙𝗶𝘁𝘂𝗿 𝗶𝗻𝗶 𝗵𝗮𝗻𝘆𝗮 𝘂𝗻𝘁𝘂𝗸 𝗮𝗱𝗺𝗶𝗻 𝗴𝗿𝘂𝗽♨️", 
botadmin: "𝗙𝗶𝘁𝘂𝗿 𝗶𝗻𝗶 𝗵𝗮𝗻𝘆𝗮 𝘂𝗻𝘁𝘂𝗸 𝗯𝗼𝘁 𝗺𝗲𝗻𝗷𝗮𝗱𝗶 𝗮𝗱𝗺𝗶𝗻🔱"
}



let file = require.resolve(__filename) 
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.cyan("File Update => "), chalk.cyan.bgBlue.bold(`${__filename}`))
delete require.cache[file]
require(file)
})