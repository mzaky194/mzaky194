require("./server/handler.js")

// >~~~~~~ Setting Bot & Owner  ~~~~~~~< //
global.owner = "-"
global.namabot = "Simple Bot V7" 
global.namaowner = "-"
global.linkgc = 'https://chat.whatsapp.com/-'
global.packname = "-"
global.author = "-"


// >~~~~~~~~ Setting Channel ~~~~~~~~~< //
global.idsaluran = "-@newsletter"
global.namasaluran = "-"
global.linksaluran = "https://whatsapp.com/channel/-"

// >~~~~ Setting Grup Reseller Panel ~~~~~< //
global.linkgrupresellerpanel = "https://chat.whatsapp.com/-"
global.apidigitalocean = "-"


// >~~~~~~~~ Setting Payment ~~~~~~~~~< //
global.dana = "-"
global.ovo = "Belum Tersedia"
global.gopay = "Belum Tersedia"
global.qris = "Belum Tersedia"


// >~~~~~~~ Setting Orderkuota ~~~~~~~~< //

global.QrisOrderKuota = ""
global.ApikeyOrderKuota = ""
global.IdMerchant = ""
global.pinH2H = ""
global.passwordH2H = ""

global.ApikeyRestApi = "new"


// >~~~~~~~~ Setting Api Panel ~~~~~~~~< //

global.egg = "15" // Isi id egg
global.nestid = "5" // Isi id nest
global.loc = "1" // Isi id location
global.domain = "https://-"
global.apikey = "-" // Isi api ptla
global.capikey = "-" // Isi api ptlc


// >~~~~~~ Setting Api Cloudflare ~~~~~~~< //

global.apitoken_cloudflare = "-"
global.accountid_cloudflare = "-"
global.email_cloudflare = "-@gmail.com"


// >~~~~~~~~ Setting Message ~~~~~~~~~< //

global.msg = {
wait: "Memproses . . .", 
owner: "Fitur ini khusus untuk owner!", 
group: "Fitur ini untuk dalam grup!", 
private: "Fitur ini untuk dalam private chat!", 
admin: "Fitur ini untuk admin grup!", 
botadmin: "Fitur ini hanya untuk bot menjadi admin"
}



let file = require.resolve(__filename) 
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.cyan("File Update => "), chalk.cyan.bgBlue.bold(`${__filename}`))
delete require.cache[file]
require(file)
})